			</div>
		</div>
		
		
		
	</div>
	
	<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../assets_student/js/jquery.bxslider.min.js"></script>
	<script type="text/javascript" src="../assets_student/js/jquery.placeholder.js"></script>
	<script type="text/javascript" src="../assets_student/js/imagesloaded.pkgd.min.js"></script>
	<script type="text/javascript" src="../assets_student/js/isotope.pkgd.min.js"></script>
	<script type="text/javascript" src="../assets_student/js/main.js"></script>
</body>
</html>