<div class="list-group">
    <a href="user/index.php" class="list-group-item">
         <i class="fa fa-user" aria-hidden="true"></i> <span>User Manager</span>
    </a> 
    <a href="student/index.php" class="list-group-item">
        <i class="fa fa-graduation-cap" aria-hidden="true"></i> <span>Students</span>
    </a>
    <a href="parents/index.php" class="list-group-item">
        <i class="fa fa-users" aria-hidden="true"></i></i> <span>Parents</span>
    </a>
    <a href="attendance/index.php" class="list-group-item">
        <i class="fa fa-calendar" aria-hidden="true"></i> <span>Attendance Manager</span>
    </a>
    <a href="audio/index.php" class="list-group-item">
        <i class="fa fa-volume-up" aria-hidden="true"></i> <span>Audio Manager</span>
    </a>
    <a href="lesson/index.php" class="list-group-item">
        <i class="fa fa-book" aria-hidden="true"></i> <span>Lessons Manager</span>
    </a>
    <a href="quiz/index.php" class="list-group-item">
        <i class="fa fa-pencil" aria-hidden="true"></i> <span>Quiz Manager</span>
    </a>
    <a href="result/index.php" class="list-group-item">
        <i class="fa fa-star" aria-hidden="true"></i> <span>Quiz Result</span>
    </a>
    <a href="story/index.php" class="list-group-item">
        <i class="fa fa-assistive-listening-systems" aria-hidden="true"></i> <span>Story Telling</span>
    </a>
    <a href="audit/index.php" class="list-group-item">
        <i class="fa fa-list" aria-hidden="true"></i> <span>Audit Trail</span>
    </a>
</div>